a=12
b=14
c=85
c1=a+b+c
print(c1)