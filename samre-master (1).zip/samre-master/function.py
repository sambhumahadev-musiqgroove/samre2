import sub
a=int(input("enter a number"))
b=int(input("enter a number"))
c=sub.Sub(a,b)
print(c)