students={"NAME":"sambhu","age":20}
print (students)
print(students["NAME"])
students["age"]=19
print (students) 