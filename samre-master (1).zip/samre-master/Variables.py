myname="samre"
lastname="sam"
print(myname+" "+lastname)