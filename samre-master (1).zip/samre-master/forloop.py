for n in range(1,100):
    if (n==10):
        break
    else:
        print(n)    