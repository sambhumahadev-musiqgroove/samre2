def Add(a,b):
    c=a+b
    return(c)