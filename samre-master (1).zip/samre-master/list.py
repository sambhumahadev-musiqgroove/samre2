subjects=["chemisty","physics","core","maths","english","biology",123]
print (subjects)
print (subjects[0:2])
del subjects[2]
print (subjects)