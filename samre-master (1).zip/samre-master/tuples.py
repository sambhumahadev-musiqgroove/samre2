tuple=("Ajith","Rehen","sambhu")
print (tuple)
del (tuple[2])
print(tuple)